The PCBs have been drawn with Eagle software 7.3.0

PCB details are in separate readme files in correct subfolders.

List of components required can be found: https://docs.google.com/spreadsheets/d/1FHOCzn1yYIiR1e6U7Qw9gCIf-KbuHXV_sOKSGwqRR3c/edit?usp=sharing

MKDSN connectors are just for PCB manufacturing to create the vias as input. They are not used but the wires are directly soldered to the vias.
