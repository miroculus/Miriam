# PCBs

The PCBs have been drawn with Eagle software 7.3.0

PCB details are in separate readme files in correct subfolders.

The Bills of material can be found under folder BOM. Datasheets of the main components are under folder Components.

Some of the component layouts can be found under Library folder that houses the Eagle .lbrs

Some of the PCBs contain MKDSN connectors. They are used just to create the vias for soldering.
