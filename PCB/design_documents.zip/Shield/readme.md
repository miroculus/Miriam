# shield_007

- material FR4

- 1oz copper
- 1.6 mm thick
- Leadfree HAL
- Black soldermask
- White silkscreen