The used board is FR4

- 1oz copper
- 1.6 mm thick
- Leadfree HAL
- White soldermask
- Black silkscreen