# Components

Components required for the PCB assembly are listed in the BOMs. Main components contain a link to the component. Datasheets can be found under ./Components.

The power source can be a normal computer ATX power supply or a nice small one like [picoPSU](http://www.mini-box.com/s.nl/it.A/id.417/.f). The emission filter is purchased from a Swedish theatrical supply store. The transmission spectrum of the [GAM-388](http://shop.hofmann.se/GAM_Orange_gold_rush_filter?id=388-GAM#.VaYDufktM9s) filter is represented in the main readme. To even out the distribution of heat an [elastic heat pressure surface](http://catalog.cshyde.com/item/all-categories/solid-silicone-thermally-conductive-/71-tcd-60d-0625) can be used between the 96-well plate and the upper heating board.

