The used board is aluminum

- 1oz copper
- 1.6 mm thick
- Leadfree HAL
- White soldermask
- Black silkscreen