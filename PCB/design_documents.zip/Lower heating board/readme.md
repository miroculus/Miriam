# LH_009

- material aluminum

- 1oz copper
- 1.6 mm thick
- Leadfree HAL
- Black soldermask
- White silkscreen