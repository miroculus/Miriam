This was ordered 1 layer aluminum and FR4 board, only bottom layer printed.

- FR4 AND ALUMINUM!
- 1oz copper
- 1.6 mm thick
- Leadfree HAL
- White soldermask
- Black silkscreen

The aluminum PCB was short circuit because the connectors were connected directly to eachother on the top side. Next time when ordering order this 2 sided aluminum, because the FR4 board created quite uniform temperature and the uniformity could be improved with aluminum.