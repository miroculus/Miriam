# Scripts

This folder has the outer dimensions of each PCB. Script template.csv is an example script to draw the traces for the heating boards. It was easiest to calculate the lengths of each wire in Excel.